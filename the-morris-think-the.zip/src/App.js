// The Morris Think - Advanced Course Selling Platform
// Full-feature React + Firebase Web App with Razorpay Integration
// Author: Morris

import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import CoursePage from "./pages/CoursePage";
import VideoPlayer from "./pages/VideoPlayer";
import AdminDashboard from "./pages/AdminDashboard";
import UploadPage from "./pages/UploadPage";
import Register from "./pages/Register";
import Login from "./pages/Login";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/course/:id" element={<CoursePage />} />
        <Route path="/video/:courseId/:videoId" element={<VideoPlayer />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/admin/upload" element={<UploadPage />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    </Router>
  );
}

/*
Features:
- HomePage: Shows 4 courses with thumbnails, reviews and intro video previews.
- Register/Login: Via Firebase Auth with mobile number and name.
- CoursePage: Shows course about, overview, demo video, enroll with Razorpay, and dynamic content after purchase.
- AdminDashboard: Full access for course upload (videos, PDFs, images, quizzes), coupons, payment management.
- UploadPage: Only admin (you) can upload content. Add separate thumbnails for course and each video.
- VideoPlayer: Shows selected video, tracks progress, and allows comments per video.
- Comments: Each video includes its own comment section.
- Firebase Firestore: Stores users, reviews, progress, uploads.
- Firebase Storage: Media content uploads.
- Razorpay Integration: One-time payments per course. Promo/coupon codes allowed.
*/
